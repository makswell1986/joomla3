<?php
/**
 * @package   AkeebaEngage
 * @copyright Copyright (c)2020-2023 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('AKENGAGE_PRO', '0');
define('AKENGAGE_VERSION', '3.3.3');
define('AKENGAGE_DATE', '2023-12-18');